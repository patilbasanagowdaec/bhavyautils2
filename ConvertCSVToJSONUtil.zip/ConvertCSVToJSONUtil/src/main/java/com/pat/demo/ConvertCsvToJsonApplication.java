package com.pat.demo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class ConvertCsvToJsonApplication implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(ConvertCsvToJsonApplication.class);
	@Autowired
	CSVToJSOnConverter cSVToJSOnConverter;
	
	@Value("${input.csv.file.path}")
	String inputCSVfilePath;
	

	@Value("${output.csv.file.path}")
	String outputCSVfilePath;

	public static void main(String[] args) {
		SpringApplication.run(ConvertCsvToJsonApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("****Read the data from csv file and prepare the resultant csv file for ingestion....*****)");
		File file = new File(inputCSVfilePath);
		logger.info("Input CSV file path :"+ inputCSVfilePath);
		logger.info("Output CSV file path :"+ outputCSVfilePath);
		
		
		//Create the output file
		FileWriter fileWriter = new FileWriter(outputCSVfilePath);
		PrintWriter printWriter = new PrintWriter(fileWriter);	
	
		//Read all the rows and keep in map
		logger.info("Reading csv file and preparing map started");
		CSVReaderUtil readerUtil = new CSVReaderUtil();	
		List<Map<String, String>> csvEntryMapList = readerUtil.readRowWiseCSVFile(file);
		logger.info("Reading csv file and preparing map completed");
		
		int lineNumber = 1;
		for(Map<String, String> rowMap : csvEntryMapList ){
			//Based on the xml keys will be changed
			Map<String, String> destMap = readerUtil.dozerConverter(rowMap);
			readerUtil.aggregatePropertiesCharges(destMap);
			readerUtil.aggregatePropertiesTaxes(destMap);
			//Convert it to String value using velocity template
			String updatedTemplate = cSVToJSOnConverter.getStringRepresentation(destMap);
			logger.info("Printing the line---" + lineNumber++);
			printWriter.println(updatedTemplate);
		}
		printWriter.close();
		logger.info("..................Completed converting files................");
		
		
		
		/*
		  Map<String, String> fieldsMapping = util.getMappingKeys();
		   for(Map<String, String> entry : csvEntryMapList ){
			Map<String, String> destMap = cSVToJSOnConverter.getConvertedMap(entry, fieldsMapping);
			String updatedTemplate = cSVToJSOnConverter.getStringRepresentation(destMap);

			String outputFileName = destMap.get("id");
			System.out.println("id::" + outputFileName);
			//writeToFile(updatedTemplate,
					//"/Users/bhavya/Documents/workspace-sts-3.8.4.RELEASE/ConvertCSVToJSON/1.json");
			//write to the file
			writeToFile(updatedTemplate,
					outputFolder+outputFileName+".json");
		}*/
	}
}
