package com.pat.demo;

public class ChargesVO {

	String min;
	String max;
	String percentage;
	String fixedAmount;
	
	
	
	public ChargesVO(String min, String max, String percentage, String fixedAmount) {
		super();
		this.min = min;
		this.max = max;
		this.percentage = percentage;
		this.fixedAmount = fixedAmount;
	}
	public String getMin() {
		return min;
	}
	public void setMin(String min) {
		this.min = min;
	}
	public String getMax() {
		return max;
	}
	public void setMax(String max) {
		this.max = max;
	}
	public String getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
	public String getFixedAmount() {
		return fixedAmount;
	}
	public void setFixedAmount(String fixedAmount) {
		this.fixedAmount = fixedAmount;
	}
	
	

}
