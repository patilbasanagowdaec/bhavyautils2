package com.pat.demo;

import java.io.StringWriter;
import java.util.Map;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.stereotype.Component;

@Component
public class CSVToJSOnConverter {

	/**
	 * Generate the template by replacing values
	 * 
	 * @param destMap
	 * @return
	 */
	String getStringRepresentation(Map<String, String> destMap) {
		VelocityEngine velocityEngine = new VelocityEngine();
		velocityEngine.setProperty("resource.loader", "class");
		velocityEngine.setProperty("class.resource.loader.class",
				"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
		velocityEngine.init();
		Template t = velocityEngine.getTemplate("CASHIN_SC.vm");
		VelocityContext context = new VelocityContext();
		for (Map.Entry<String, String> entry : destMap.entrySet()) {
			context.put(entry.getKey(), entry.getValue());
		}
		StringWriter writer = new StringWriter();
		t.merge(context, writer);
		// TODO write to the file
		return writer.toString();
	}

	

}
