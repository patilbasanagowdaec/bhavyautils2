package com.pat.demo;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

public class CSVReaderUtil {

	Logger logger = LoggerFactory.getLogger(CSVReaderUtil.class);
	
	/**
	 * Read all the rows of the file and store each line as map
	 * @param file
	 * @return
	 */
	public List<Map<String, String>> readRowWiseCSVFile(File file) {
		List<Map<String, String>> csvFileMapList = new ArrayList<>();
		try {
			// Create an object of file reader class with CSV file as a parameter.
			FileReader filereader = new FileReader(file);
			// read all the lines of file
			CSVReader csvReader = new CSVReaderBuilder(filereader).build();
			List<String[]> allData = csvReader.readAll();
			
			for (String[] rowArray : allData) {
				Map<String, String> csvFileMap = new HashMap<>();
				for (String row : rowArray) {
					// row seperate it by # for each column
					String[] fieldsArray = row.split("##");
					if (fieldsArray != null && fieldsArray.length > 0) {
						
						for(String field :  fieldsArray){
							// populate single field by splitting it based on #
							String[] fieldValueArray = field.split("#");
							if (fieldValueArray != null && fieldValueArray.length > 1) {
								String key = StringUtils.removeEnd(StringUtils.removeFirst(fieldValueArray[0], "\""), "\"");
								String value = fieldValueArray[1] != null && fieldValueArray[1].contains("\"") ?StringUtils.removeEnd(StringUtils.removeFirst(fieldValueArray[1], "\""), "\""): null;
								if(key.equals("SC_ServiceChargeId") || key.equals("Id"))
								{
									UUID uuid = UUID.randomUUID();
									value= uuid.toString();
									//System.out.println(value);
								}
								csvFileMap.put(key, value);
								//System.out.println(key + "\t" + value + "\t");
								
							} else {
								// to handle empty rows
								if (fieldValueArray[0] != null && fieldValueArray[0].length() > 0) {
									String key = fieldValueArray[0].substring(0, fieldValueArray[0].lastIndexOf("\""));
									csvFileMap.put(key, null);
									System.out.println(key + "\t");
								}
							}
						}
						
					}
					

				}
				csvFileMapList.add(csvFileMap);
			}
		} catch (Exception e) {
			logger.error("Error in reading file and preparing map " + e.getMessage());
			System.out.println("Error in reading csv file" + e.getMessage());
		}
	
		return csvFileMapList;

	}	
	
	
	/**
	 * Based on the mapping chnage the assignment keys as in mapping file
	 * @param csvFileMap
	 * @return
	 */
	public Map<String, String> dozerConverter(Map<String, String> csvFileMap){
		DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();
		dozerBeanMapper.setMappingFiles(Arrays.asList("CASHIN_SC.xml"));
		Map<String, String> destFileMap = dozerBeanMapper.map(csvFileMap , HashMap.class , "BULK_BILLPAY");
		for (Map.Entry<String,String> entry : destFileMap.entrySet()) {
			logger.debug( entry.getKey() +":" + entry.getValue()); 
		}
		return destFileMap;
    }
		
	
	/**
	 * Aggreagate all the charges
	 * @param destMap
	 */
	public void aggregatePropertiesCharges(Map<String, String> destMap ){
		List<ChargesVO> chargesList = new ArrayList<>();
		String minName="SCfromrangeslab";
		String maxName="SCtorangeslab";
		String percentage="servicechargeslab";
		String fixedAmount="servicechargeslab";
		
		for(int i=0 ; i<=40 ; i++){
			//consider only non null values
			if(destMap.get(minName +String.valueOf(i)) != null){
				chargesList.add(new ChargesVO(destMap.get(minName +String.valueOf(i)), destMap.get(maxName +String.valueOf(i)),
						destMap.get(percentage +String.valueOf(i) +"per"), destMap.get(fixedAmount +String.valueOf(i) +"fixed")));
			}
			
		}
		String pricingSlabs_array = new Gson().toJson(chargesList);
		destMap.put("chargesstmnts_pricingSlabs_array", pricingSlabs_array);
		System.out.println(pricingSlabs_array);
	}
	
	
	
	/**
	 * Aggreagate all the taxes
	 * @param destMap
	 */
	public void aggregatePropertiesTaxes(Map<String, String> destMap ){
		List<TaxesVO> taxList = new ArrayList<>();
		String minName="taxSCfromrangeslab";
		String maxName="taxSCtorangeslab";
		String percentage="taxSCslab";
		String fixedAmount="taxSCslab";
		
		for(int i=0 ; i<=5 ; i++){
			//consider only non null values
			if(destMap.get(minName +String.valueOf(i)) != null){
				taxList.add(new TaxesVO(destMap.get(minName +String.valueOf(i)), destMap.get(maxName +String.valueOf(i)),
						destMap.get(percentage +String.valueOf(i) +"per"), destMap.get(fixedAmount +String.valueOf(i) +"fixed")));
			}
		}
		String pricingSlabs_array = new Gson().toJson(taxList);
		destMap.put("tax_rules_pricingSlabs_array", pricingSlabs_array);
		System.out.println(pricingSlabs_array);
	}
	
	
	
	
	
/*	Map<String , String> getMappingKeys(){
		Map<String, String> map = new HashMap<>();
		map.put("Sender MFS Provider", "sendermfsprovider");
		map.put("Sender Wallet Type/ Linked Bank", "senderwallet/tbank");
		map.put("Sender Grade", "sendergrade");
		map.put("Receiver Grade", "receivergrade");
		map.put("Service", "service");
		map.put("Paying Entity - Sender name", "payingentity");
		map.put("Credited Entity - Receiver name", "creditedentity");
		map.put("min Fixed Service charge ", "minfixedservicecharge");
		map.put("max Fixed Service Charge", "maxfixedservicecharge");
		map.put("Telescopic Pricing On Service Charge", "telescopicpricingonsc");
		map.put("SC From Range slab-0", "SCfromrangeslab0");
		map.put("SC To Range slab-0", "SCtorangeslab0");
		map.put("Service Charge slab-0(%)", "servicechargeslab0(%)");
		map.put("Service Charge slab-0(fixed)", "servicechargeslab0(fixed)");
		map.put("SC From Range slab-1", "SCfromrangeslab1");
		map.put("id", "id");
		//TODO add remaning fields
		
		return map;
	}*/
	
	
	
	

	/*public void writeToFile(String fileContent, String fileName)
			throws IOException {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
			writer.write(fileContent);

			writer.close();
		} catch (Exception e) {
			System.out.println("Exception in writing file" +e.getMessage());
		}

	}	*/


			
				
		
	
	
	
	/*public static void main(String[] args) {
		Map<String,String> csvFileMap = new HashMap<>(); 
		csvFileMap.put("Sender MFS Provider", "bhavya");
		csvFileMap.put("Sender Grade", "patil");
		csvFileMap.put("Sender Wallet Type/ Linked Bank", "patilspeci");
		dozerConverter(csvFileMap);
	}*/
	
	
	
	

}
